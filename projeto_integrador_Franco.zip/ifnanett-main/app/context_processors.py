from .models import Notificacao

def notificacoes_context(request):
    if request.user.is_authenticated:
        notificacoes = Notificacao.objects.filter(usuario=request.user).order_by('-criado_em')[:10]  # Limitar a 10 mais recentes
    else:
        notificacoes = []
    return {'notificacoes_globais': notificacoes}
