from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages  
from .models import CustomUser  # Certifique-se de que está importando seu modelo CustomUser
from .forms import EditProfileForm, EditPerfilUsuarioForm  # Importando os formulários
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .forms import CustomUserForm 
from .forms import UserUpdateForm   
from django.http import HttpResponse 
from django.contrib.auth.decorators import login_required
from .models import Suporte
from django.contrib.auth.decorators import login_required
from .models import Postagem
from .forms import PostagemForm
from django.shortcuts import get_object_or_404, redirect
from .models import Comentario
from django.contrib.auth.views import PasswordResetView
from .forms import CustomPasswordResetForm
from django.contrib.auth.decorators import user_passes_test
from .forms import TarefaForm
from .models import Tarefa
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import Tarefa  # Supondo que você tenha um modelo Tarefa
from .models import Notificacao
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Mensagem
from .models import Amizade
from django.contrib.auth import get_user_model
from django.db import models  # Importação do models

def adicionar_tarefa(request):
    if request.method == 'POST':
        form = TarefaForm(request.POST)
        if form.is_valid():
            tarefa = form.save(commit=False)
            tarefa.usuario = request.nome  # Associa a tarefa ao usuário logado
            tarefa.save()
            return redirect('agenda')  # Redireciona para a página de agenda ou onde preferir
    else:
        form = TarefaForm()
    
    return render(request, 'adicionar_tarefa.html', {'form': form})

def agenda(request):
    tarefas = Tarefa.objects.filter(usuario=request.user)  # Filtra as tarefas do usuário logado
    return render(request, 'agenda.html', {'tarefas': tarefas})


def remover_tarefa(request, id):
    tarefa = Tarefa.objects.get(id=id)
    if tarefa.usuario == request.user:  # Verifica se o usuário é o dono da tarefa
        tarefa.delete()  # Deleta a tarefa
    return redirect('agenda')  # Redireciona de volta para a página da agenda

@login_required
def agenda(request):
    if request.method == 'POST':
        form = TarefaForm(request.POST)
        if form.is_valid():
            tarefa = form.save(commit=False)
            tarefa.usuario = request.user  # Associa a tarefa ao usuário logado
            tarefa.save()
            return redirect('agenda')  # Redireciona para a página da agenda após salvar

    else:
        form = TarefaForm()

    # Obtém as tarefas do usuário logado
    tarefas = Tarefa.objects.filter(usuario=request.user).order_by('-data_criacao')

    return render(request, 'agenda.html', {'form': form, 'tarefas': tarefas})

class IndexView(View):
    def get(self, request):
        # Obtém todas as postagens, ordenadas pela data de publicação
        postagens = Postagem.objects.all().order_by('-data_publicacao')  # Use 'data_publicacao' em vez de 'data_postagem'
        
        # Obtém todos os usuários, exceto o logado
        usuarios = User.objects.exclude(id=request.user.id)
        
        # Obtém os IDs dos amigos do usuário logado
        amigos_ids = Amizade.objects.filter(usuario=request.user).values_list('amigo__id', flat=True)
        
        # Passa as postagens, os usuários e os IDs dos amigos para o template
        return render(request, 'index.html', {
            'postagens': postagens,
            'usuarios': usuarios,
            'amigos_ids': amigos_ids
        })
class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')

        if email and password:
            try:
                user = CustomUser.objects.get(email=email)
            except CustomUser.DoesNotExist:
                user = None
            
            if user:
                user = authenticate(request, username=user.email, password=password)
                if user is not None:
                    login(request, user)
                    return redirect('index')  # Redireciona para a página principal
                else:
                    messages.error(request, 'Senha incorreta.')
            else:
                messages.error(request, 'Email não encontrado.')
        else:
            messages.error(request, 'Por favor, preencha todos os campos.')
    
        return render(request, 'login.html')

@login_required
def perfil(request):
    user = request.user  # Obtém o usuário atual
    return render(request, 'perfil.html', {'user': user})

class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        nome = request.POST.get('nome')
        sobrenome = request.POST.get('sobrenome')
        if CustomUser.objects.filter(email=email).exists():
            return render(request, 'register.html', {'error': 'Email já existe'})
        
        user = CustomUser.objects.create_user(email=email, password=password,nome=nome, sobrenome=sobrenome)
        user.save()
        login(request, user)  # Faz login automaticamente após o registro
        return redirect('index')


class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')  # Redireciona para a página de login após logout


@login_required
def perfil_view(request):
    usuario = request.user
    postagens = Postagem.objects.filter(usuario=usuario).prefetch_related('comentarios', 'curtidas')
    return render(request, 'perfil.html', {'user': usuario, 'postagens': postagens})
def editar_perfil(request):
    if request.method == 'POST':
        form = UserUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('perfil')  # Redirecionar para a página de perfil após salvar
    else:
        form = UserUpdateForm(instance=request.user)

    return render(request, 'editar_perfil.html', {'form': form})
@login_required
def edit_profile_view(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Perfil atualizado com sucesso!')
            return redirect('perfil')  # Certifique-se de que a URL 'perfil' está correta
    else:
        form = EditProfileForm(instance=request.user)
    return render(request, 'editar_perfil.html', {'form': form})

class SuporteView(View):
    def get(self, request):
        return render(request, 'suporte.html')

    def post(self, request):
        # Lógica para enviar suporte
        pass


class PostarView(View):
    def get(self, request):
        return render(request, 'postar.html')

    def post(self, request):
        # Lógica para postar
        pass




class EditarUsuarioView(View):
    @login_required
    def get(self, request):
        user = request.user.usuario
        form = EditUsuarioForm(instance=user)
        return render(request, 'editar_usuario.html', {'form': form})

    @login_required
    def post(self, request):
        user = request.user.usuario
        form = EditUsuarioForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Usuário atualizado com sucesso!')
            return redirect('perfil')
        return render(request, 'editar_usuario.html', {'form': form})


class EditarPerfilUsuarioView(View):
    @login_required
    def get(self, request):
        perfil = request.user.perfilusuario
        form = EditPerfilUsuarioForm(instance=perfil)
        return render(request, 'editar_perfil_usuario.html', {'form': form})

    @login_required
    def post(self, request):
        perfil = request.user.perfilusuario
        form = EditPerfilUsuarioForm(request.POST, request.FILES, instance=perfil)
        if form.is_valid():
            form.save()
            messages.success(request, 'Perfil de usuário atualizado com sucesso!')
            return redirect('perfil')
        return render(request, 'editar_perfil_usuario.html', {'form': form})


@login_required
def suporte_view(request):
    print("Requisição recebida: ", request.method)  # Adicione este print
    if request.method == "POST":
        usuario = request.user
        assunto = request.POST.get('assunto')
        mensagem = request.POST.get('mensagem')
        status = 'Em aberto'  # Definindo um status padrão para a mensagem de suporte

        # Salva o suporte no banco de dados
        Suporte.objects.create(usuario=usuario, assunto=assunto, mensagem=mensagem, status=status)

        # Mensagem de sucesso
        messages.success(request, 'Sua mensagem foi enviada com sucesso!')
        
        # Redireciona para a página de suporte ou para onde você quiser
        return redirect('suporte')  

    print("Renderizando o template suporte.html")  # Adicione este print
    return render(request, 'suporte.html')   

class PostarView(LoginRequiredMixin, View):  # Adicione o mixin antes de View
    login_url = 'login'  # URL para onde o usuário será redirecionado se não estiver logado

    def get(self, request):
        return render(request, 'postar.html')  # Página para criar postagens
    
    def post(self, request):
        titulo = request.POST.get('titulo')
        imagem = request.FILES.get('imagem')  # Obtém a imagem do formulário
        usuario = request.user  # Usuário atual

        # Cria uma nova postagem
        Postagem.objects.create(titulo=titulo, imagem=imagem, usuario=usuario)
        return redirect('index')  # Redireciona para a página principal após criar a postagem

@login_required
def criar_postagem(request):
    if request.method == 'POST':
        titulo = request.POST.get('titulo')
        imagem = request.FILES.get('imagem')  # Obtém a imagem do formulário
        usuario = request.user  # Usuário atual

        # Verifica se o título não está vazio
        if titulo:
            # Cria uma nova postagem
            Postagem.objects.create(titulo=titulo, imagem=imagem, usuario=usuario)
            messages.success(request, "Postagem criada com sucesso!")  # Mensagem de sucesso
            return redirect('index')  # Redireciona para a página principal após criar a postagem
        else:
            messages.error(request, "O título é obrigatório.")  # Mensagem de erro se o título estiver vazio

    return render(request, 'criar_postagem.html')  # Rend
    
class DeletePostView(View):
    def post(self, request, id):
        # Usando get_object_or_404 para lidar com o caso de o objeto não existir
        postagem = get_object_or_404(Postagem, id=id)
        postagem.delete()
        return redirect('index')  # Redireciona para a página inicia
    
    
@login_required
def comentar_postagem(request, postagem_id):
    postagem = Postagem.objects.get(id=postagem_id)
    notificacao = Notificacao.objects.create(
            usuario=postagem.usuario,
            tipo='comentar',
            texto=f"{request.user.nome} comentou em sua postagem.",
        )
    if request.method == 'POST':
        conteudo = request.POST['conteudo']
        comentario = Comentario(postagem=postagem, usuario=request.user, conteudo=conteudo)
        comentario.save()

     
    return redirect('index')

@login_required

def curtir_postagem(request, postagem_id):
    postagem = get_object_or_404(Postagem, id=postagem_id)
    
    # Verifica se o usuário já curtiu a postagem
    if request.user in postagem.curtidas.all():
        postagem.curtidas.remove(request.user)  # Remove a curtida se o usuário já tiver curtido
    else:
        postagem.curtidas.add(request.user)  # Adiciona a curtida se o usuário não tiver curtido ainda
    
    
        
        # Criando a notificação de curtida
        notificacao = Notificacao.objects.create(
            usuario=postagem.usuario,
            tipo='curtir',
            texto=f"{request.user.nome} curtiu sua postagem.",
        )

    return redirect('index')  # Redireciona de volta para o index (ou outra página que deseje)
    


class CustomPasswordResetView(PasswordResetView):
    form_class = CustomPasswordResetForm
    template_name = 'seu_template/password_reset.html'  # Ajuste o caminho do template
    email_template_name = 'seu_template/password_reset_email.html'  # Ajuste o caminho do email
    subject_template_name = 'seu_template/password_reset_subject.txt'  # Ajuste o caminho do assunto
    success_url = 'password_reset_done/'  # Ajuste a URL conforme necessário
    
def is_admin(user):
    return user.is_staff

# Dashboard administrativo
@user_passes_test(is_admin)
def admin_dashboard(request):
    return render(request, 'admin_dashboard.html')

# Listagem de usuários
@user_passes_test(is_admin)
def admin_users(request):
    usuarios = CustomUser.objects.all()
    return render(request, 'admin_users.html', {'usuarios': usuarios})

# Listagem de mensagens de suporte
@user_passes_test(is_admin)
def admin_support(request):
    mensagens = Suporte.objects.all()  # Busca todas as mensagens de suporte
    return render(request, 'admin_support.html', {'mensagens': mensagens})
# Apagar usuário
@user_passes_test(is_admin)
def delete_user(request, user_id):
    usuario = get_object_or_404(CustomUser, id=user_id)
    usuario.delete()
    return redirect('admin_users')

def inicio_view(request):
    return render(request, 'index.html')  # Renderiza a página início.html

@login_required
def deletar_comentario(request, comentario_id):
    comentario = get_object_or_404(Comentario, id=comentario_id)

    # Verifica se o usuário é o dono do comentário ou administrador
    if request.user == comentario.usuario or request.user.is_superuser:
        comentario.delete()
        messages.success(request, 'Comentário apagado com sucesso!')
    else:
        messages.error(request, 'Você não tem permissão para apagar este comentário.')

    return redirect('index')  # Altere para a página correta de redirecionamento

@login_required
def deletar_conta(request):
    if request.method == 'POST':
        # Apagar a conta do usuário
        request.user.delete()
        messages.success(request, "Conta apagada com sucesso.")
        return redirect('index')  # Redireciona para a página i
    
@login_required
def agenda(request):
    tarefas = Tarefa.objects.filter(usuario=request.user)  # Filtra as tarefas para o usuário logado

    if request.method == 'POST':
        tarefa_nome = request.POST.get('tarefa')
        if tarefa_nome:
            # Cria a nova tarefa associada ao usuário logado, sem necessidade de passar o nome do usuário
            Tarefa.objects.create(nome=tarefa_nome, usuario=request.user)
            tarefas = Tarefa.objects.filter(usuario=request.user)  # Recarrega as tarefas para o usuário logado

    return render(request, 'agenda.html', {'tarefas': tarefas})

def perfil_usuario(request, usuario_id):
    usuario = get_object_or_404(CustomUser, id=usuario_id)
    postagens = Postagem.objects.filter(usuario=usuario).order_by('-data_publicacao')  # Buscar postagens do usuário
    return render(request, 'perfil_usuario.html', {'usuario': usuario, 'postagens': postagens})

def notificacoes_usuario(request):
    notificacoes = Notificacao.objects.filter(usuario=request.nome, visualizado=False)
    return render(request, 'notificacoes.html', {'notificacoes': notificacoes})

from django.shortcuts import render

User = get_user_model()
def notificacoes(request):
    notificacoes = Notificacao.objects.filter(usuario=request.user).order_by('-criado_em')
    return render(request, 'notificacoes.html', {'notificacoes': notificacoes})
@login_required
def chat(request, nome):
    destinatario = User.objects.get(nome=nome)  # Use "nome" no lugar de "username"
    mensagens = Mensagem.objects.filter(
        (models.Q(remetente=request.user) & models.Q(destinatario=destinatario)) |
        (models.Q(remetente=destinatario) & models.Q(destinatario=request.user))
    ).order_by('timestamp')

    if request.method == 'POST':
        conteudo = request.POST.get('conteudo')
        if conteudo:
            Mensagem.objects.create(remetente=request.user, destinatario=destinatario, conteudo=conteudo)
        return redirect('chat', nome=nome)

    return render(request, 'chat.html', {'destinatario': destinatario, 'mensagens': mensagens})
@login_required
def adicionar_amigo(request, usuario_id):
    """Adiciona um amigo à lista de amigos do usuário"""
    amigo = User.objects.get(id=usuario_id)
    if amigo != request.user:  # Garantir que não estamos tentando adicionar o próprio usuário
        # Verificar se a amizade já existe
        if not Amizade.objects.filter(usuario=request.user, amigo=amigo).exists():
            Amizade.objects.create(usuario=request.user, amigo=amigo)
            return redirect('index')  # Redireciona de volta para o feed após adicionar o amigo
    return redirect('index')  # Redireciona de volta se já for amigo ou tentar adicionar o próprio usuário

@login_required
def lista_amigos(request):
    """Exibe a lista de amigos do usuário"""
    amigos = Amizade.objects.filter(usuario=request.user)
    amigos_ids = amigos.values_list('amigo__id', flat=True)  # Lista de IDs dos amigos
    usuarios = User.objects.all()  # Todos os usuários para exibir na lista
    
    
    return render(request, 'amigos.html', {
        'amigos': amigos, 
        'amigos_ids': amigos_ids, 
        'usuarios': usuarios
    })

@login_required
def remover_amigo(request, amizade_id):
    amizade = get_object_or_404(Amizade, id=amizade_id)

    # Verificar se o usuário atual é o dono de uma das partes da amizade
    if amizade.usuario == request.user or amizade.amigo == request.user:
        amizade.delete()
        return redirect('lista_amigos')  # Redireciona de volta para a lista de amigos
    else:
        return redirect('lista_amigos')  #